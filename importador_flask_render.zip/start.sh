#!/bin/bash
gunicorn app:app